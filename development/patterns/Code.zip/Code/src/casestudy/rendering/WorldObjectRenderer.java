package casestudy.rendering;

import casestudy.documentstructure.improved.WorldObject;

public interface WorldObjectRenderer {

	public void render(WorldObject object);
	
}
