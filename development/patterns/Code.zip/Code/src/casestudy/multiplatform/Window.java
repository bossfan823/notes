package casestudy.multiplatform;

public abstract class Window {

	/**
	 * Draw window on the screen
	 */
	public abstract void drawWindow();
	
}
