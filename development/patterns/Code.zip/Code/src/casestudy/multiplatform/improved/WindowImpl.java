package casestudy.multiplatform.improved;

public interface WindowImpl {

	public void drawWindow();
	
}
