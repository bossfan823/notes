package casestudy.multiplatform.improved;

public class MacWindowImpl implements WindowImpl{

	@Override
	public void drawWindow() {
		System.out.println("Draw application window for Mac");
	}

	
	
}
