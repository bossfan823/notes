package casestudy.multiplatform.improved;

public class WindowsWindowImpl implements WindowImpl{

	@Override
	public void drawWindow() {
		System.out.println("Draw application window for Windows");
		
	}

	
	
}
