package behavioral.visitor.improved;


public class Wheel extends CarPart {

}
