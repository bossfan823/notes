package behavioral.mediator.improved;


public interface Screendirector {

    void itemSelected(String item);

}
