package behavioral.command.improved;


public interface Command {

    void action();

    void undo();


}
