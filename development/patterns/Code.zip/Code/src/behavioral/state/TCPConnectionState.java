package behavioral.state;


public enum TCPConnectionState {

    OPEN,
    CLOSED

}
