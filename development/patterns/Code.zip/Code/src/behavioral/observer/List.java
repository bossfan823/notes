package behavioral.observer;


public class List {

    public void setListValue(int value){
        System.out.println("Set list value : "+value);
    }

}
