package behavioral.strategy;


public enum Difficulty {

    EASY,
    MEDIUM,
    HARD

}
