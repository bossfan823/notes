package creational.abstractfactory;

public class YellowThemeScrollbar implements ScrollBar {

}
