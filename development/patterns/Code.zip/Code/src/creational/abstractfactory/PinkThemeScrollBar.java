package creational.abstractfactory;

public class PinkThemeScrollBar implements ScrollBar {

}
