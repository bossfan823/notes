package creational.abstractfactory.improved;

public interface Window {

}
