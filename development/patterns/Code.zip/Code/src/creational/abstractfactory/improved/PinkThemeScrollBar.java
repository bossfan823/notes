package creational.abstractfactory.improved;

public class PinkThemeScrollBar implements ScrollBar{

}
