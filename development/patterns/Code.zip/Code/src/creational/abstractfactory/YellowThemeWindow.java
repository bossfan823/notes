package creational.abstractfactory;

public class YellowThemeWindow implements Window {

}
