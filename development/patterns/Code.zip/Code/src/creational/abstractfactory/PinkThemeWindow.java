package creational.abstractfactory;

public class PinkThemeWindow implements Window {

}
