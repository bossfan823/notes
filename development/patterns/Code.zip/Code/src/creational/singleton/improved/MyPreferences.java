package creational.singleton.improved;


public class MyPreferences extends Preferences{
}
