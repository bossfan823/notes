package creational.builder;

public interface Query {

	void execute();
	
}
