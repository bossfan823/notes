package creational.prototype;

public class Video extends Graphic {

	private String url;

	public void setUrl(String url) {
		this.url = url;
	}
	
}
