package creational.prototype;

public class Image extends Graphic {

	private String url;

	public void setUrl(String url) {
		this.url = url;
	}
	
}
