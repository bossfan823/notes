package creational.prototype;

public abstract class Graphic {

	
}
