package additional.ioc;


public interface FileSystem {

    String readFile();

}
