package additional.ioc.improved;


public interface FileSystem {

    String readFile();

}
