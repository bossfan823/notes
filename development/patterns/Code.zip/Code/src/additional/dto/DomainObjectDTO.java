package additional.dto;


public class DomainObjectDTO {

    private String aProperty;


    public String getaProperty() {
        return aProperty;
    }

    public void setaProperty(String aProperty) {
        this.aProperty = aProperty;
    }
}
