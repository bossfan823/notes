package additional.dto;


public class DomainObject {

    private String aProperty;

    private String confedential;

    public String getaProperty() {
        return aProperty;
    }

    public void setaProperty(String aProperty) {
        this.aProperty = aProperty;
    }

    public String getConfedential() {
        return confedential;
    }

    public void setConfedential(String confedential) {
        this.confedential = confedential;
    }
}
