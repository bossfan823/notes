package structural.decorator.improved;


public class Window {

    public void draw(){
        System.out.println("Drawing window");
    }

}
