package structural.composite;


public class Rectangle {

    public void draw(){
        System.out.println("Drawing a rectangle");
    }

}
