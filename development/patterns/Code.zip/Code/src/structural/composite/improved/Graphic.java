package structural.composite.improved;


public interface Graphic {

    void draw();

}
