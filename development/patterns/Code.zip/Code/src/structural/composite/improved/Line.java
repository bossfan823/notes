package structural.composite.improved;


public class Line implements Graphic{

    public void draw(){
        System.out.println("Draw line");
    }

}
