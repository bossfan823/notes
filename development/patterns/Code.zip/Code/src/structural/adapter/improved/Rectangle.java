package structural.adapter.improved;

public class Rectangle {

	public Integer determineSize(){
		return 5;
	}
	
}
