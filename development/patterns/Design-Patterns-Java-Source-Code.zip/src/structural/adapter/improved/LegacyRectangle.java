package structural.adapter.improved;

public class LegacyRectangle {

	public Integer calculateSize(){
		return 10;
	}
	
}
