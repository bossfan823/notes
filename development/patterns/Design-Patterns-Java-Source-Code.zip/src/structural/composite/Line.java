package structural.composite;


public class Line {

    public void draw(){
        System.out.println("Drawing a line");
    }

}
