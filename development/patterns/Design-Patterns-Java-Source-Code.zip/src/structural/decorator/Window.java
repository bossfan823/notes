package structural.decorator;


public class Window {

    public void draw(){
        System.out.println("Drawing window");
    }

}
