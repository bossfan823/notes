package casestudy.documentstructure;

public class Square {

	public void print(){
		System.out.println("Square");
	}
	
}
