package casestudy.documentstructure;

public class Circle {

	public void print(){
		System.out.println("Circle");
	}
	
}
