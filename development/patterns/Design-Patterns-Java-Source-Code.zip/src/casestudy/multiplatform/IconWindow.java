package casestudy.multiplatform;

public abstract class IconWindow extends Window{

	/**
	 * Adds icon to the window after it has been drawn
	 */
	public abstract void drawIconWindow();

}
