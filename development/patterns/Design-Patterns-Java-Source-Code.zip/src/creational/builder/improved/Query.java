package creational.builder.improved;

public interface Query {

	void execute();
	
}
