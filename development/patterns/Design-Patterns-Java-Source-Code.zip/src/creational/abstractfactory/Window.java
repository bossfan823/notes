package creational.abstractfactory;

public interface Window {

}
