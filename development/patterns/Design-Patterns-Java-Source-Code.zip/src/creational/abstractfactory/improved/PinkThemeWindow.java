package creational.abstractfactory.improved;

public class PinkThemeWindow implements Window {

}
