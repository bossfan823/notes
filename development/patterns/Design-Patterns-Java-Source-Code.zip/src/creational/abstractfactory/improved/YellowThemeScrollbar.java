package creational.abstractfactory.improved;

public class YellowThemeScrollbar implements ScrollBar{

}
