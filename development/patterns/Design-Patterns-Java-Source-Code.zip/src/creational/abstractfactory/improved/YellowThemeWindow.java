package creational.abstractfactory.improved;

public class YellowThemeWindow implements Window{

}
