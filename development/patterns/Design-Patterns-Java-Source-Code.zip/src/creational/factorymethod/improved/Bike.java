package creational.factorymethod.improved;

public class Bike extends Transport{

	public String drive() {
		return "Bike driving";
	}

}
