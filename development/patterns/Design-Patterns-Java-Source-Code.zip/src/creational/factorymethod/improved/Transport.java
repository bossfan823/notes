package creational.factorymethod.improved;

public abstract class Transport {

    public abstract String drive();



}
