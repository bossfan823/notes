package creational.factorymethod.improved;

public class Car extends Transport{

	public String drive() {
		return "Car driving"; 
	}

}
