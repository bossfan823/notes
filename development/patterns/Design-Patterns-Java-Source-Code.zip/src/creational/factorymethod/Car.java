package creational.factorymethod;


public class Car extends Transport {
}
