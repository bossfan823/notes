package creational.factorymethod;

public class Transport {
	
	public String drive(){
        return "I'm a transport driving";
    }

}
