package behavioral.observer.improved;


public interface Observer {

    void update();

}
