package behavioral.observer;


public class InputText {

    public void setText(String text){
        System.out.print("Inputtext set text: "+text);
    }

}
