package behavioral.visitor.improved;


public class Engine extends CarPart {

}
