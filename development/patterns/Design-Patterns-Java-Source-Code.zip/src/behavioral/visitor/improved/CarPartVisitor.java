package behavioral.visitor.improved;


public interface CarPartVisitor {

    void visit(CarPart carPart);

}
