package behavioral.visitor.improved;


public class Light extends CarPart {


}
